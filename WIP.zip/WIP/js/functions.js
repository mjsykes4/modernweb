function displayName(name){
    console.log("Hello, " + name)
}

displayName("Mike");

function celciusToFahrenheit(fahrenheit){

    console.log("In Fahrenheit this temp is " + fahrenheit)
}

