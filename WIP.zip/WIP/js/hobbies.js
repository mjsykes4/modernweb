const hobbiesArray=[
    {name: 'soccer', lengthInYearsAtHobby: 25},
    {name: 'hiking', lengthInYearsAtHobby: 2},
    {name: 'sleeping', lengthInYearsAtHobby: 31}]

    function callToHobby(hobby){
        console.log(`I have played  ${hobby.name} for ${hobby.lengthInYearsAtHobby}`);

        for(let index = 0; index < hobbiesArray.length; index++){
            callToHobby(hobbiesArray[index]);
        } 
    }