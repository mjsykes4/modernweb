let arrayOfHobbies = ['soccer', 'sleeping', 'hiking'];

function printHobbies(myhobbies) {
    console.log(`I like  ${myhobbies.length} things:`);
    for (let index = 0; index < arrayOfHobbies.length; index++) {
        let hobbies = arrayOfHobbies[index];
        console.log('I like ' + hobbies);
    }
}

printHobbies(arrayOfHobbies);

let myColor = ['Red', 'Green', 'White', 'Black'];

console.log(myColor.join(','));
console.log(myColor.join(','));
console.log(myColor.join('+'));